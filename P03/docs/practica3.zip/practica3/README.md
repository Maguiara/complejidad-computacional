# Práctica 3: Funciones primitivas recursivas de números naturales

Universidad de La Laguna · Grado en Ingeniería Informática · Complejidad Computacional (curso 2026/27)

Autor: Marco Aguiar Álvarez

Calcula `potencia(x, y) = x^y` como función primitiva recursiva, construida
únicamente a partir de las funciones básicas **Z**, **S** y **P<sub>i</sub><sup>n</sup>**
mediante las operaciones de **composición** y **recursión primitiva**. Muestra el
resultado y el número de llamadas a funciones realizadas.

## Estructura del proyecto

```
practica3/
├── CMakeLists.txt
├── README.md
├── include/                  Cabeceras
│   ├── natural.h             Natural = std::uint64_t
│   ├── call_counter.h        Contador de llamadas y control de profundidad
│   ├── function.h            Clase base abstracta Function
│   ├── basic_functions.h     Zero, Successor, Projection
│   ├── composition.h         Operación de composición
│   ├── primitive_recursion.h Operación de recursión primitiva
│   ├── primitive_recursive.h Construcción de suma, producto y potencia
│   └── tools.h               Lectura de los parámetros -x e -y
└── src/                      Implementaciones y main.cc
```

## Compilación y ejecución

```
cmake -S . -B build
cmake --build build
./build/potencia -x <natural> -y <natural>
```

Ejemplo:

```
$ ./build/potencia -x 2 -y 3
Resultado: 2^3 = 8
Numero de llamadas a funciones: 114
```

## Diseño orientado a objetos

| Clase | Papel |
|---|---|
| `Function` | Clase base abstracta (función `N^k -> N`). Comprueba la aridad y cuenta la llamada en `operator()`; cada subclase implementa `Compute`. |
| `Zero`, `Successor`, `Projection` | Funciones básicas `Z(x)=0`, `S(x)=x+1`, `P_i^n(x_1..x_n)=x_i`. |
| `Composition` | `f(x) = h(g_1(x), ..., g_m(x))`. Valida las aridades al construirse. |
| `PrimitiveRecursion` | `f(x,0)=g(x)`; `f(x,y+1)=h(x,y,f(x,y))`. Valida `aridad(h) = aridad(g)+2`. |
| `CallCounter` | Contador compartido por todas las funciones y límite de profundidad. |
| `PrimitiveRecursive` | Construye suma, producto y potencia componiendo los objetos anteriores. |

## Definición formal implementada

```
suma(x, 0)     = P_1^1(x)
suma(x, y+1)   = S(P_3^3(x, y, suma(x, y)))

producto(x, 0)   = Z(x)
producto(x, y+1) = suma(P_3^3(x, y, producto(x, y)), P_1^3(x, y, producto(x, y)))

potencia(x, 0)   = S(Z(x))
potencia(x, y+1) = producto(P_3^3(x, y, potencia(x, y)), P_1^3(x, y, potencia(x, y)))
```

## Criterio de conteo de llamadas

Se cuenta **una llamada por cada evaluación de una función**, sea básica
(Z, S, P), compuesta (una `Composition`) o definida por recursión primitiva
(cada paso recursivo `f(x, y-1)` cuenta como una evaluación de `f`). Las
proyecciones del esquema formal también se cuentan.

Coste de cada función (con `x` fijo en `producto` y `potencia`):

- `suma(·, b)`: `2 + 4b`
- `producto(a, b)`: `2 + b·(6 + 4a)`
- `potencia(x, y)`: `4 + y·(6 + 6x) + 4·(x + x² + ... + x^y)`

Para `2^3`: `4 + 3·18 + 4·(2+4+8) = 114` llamadas.

## Límites

- Los valores son `uint64_t`; si el resultado no cabe se lanza un error de desbordamiento.
- Como las funciones se evalúan de forma recursiva (en unario), la profundidad
  crece con el valor de los operandos. Se limita a 1024 niveles
  (`kMaxDepth` en `call_counter.h`) para no agotar la pila; p. ej. `2^10` funciona
  y `2^12` informa del límite.
